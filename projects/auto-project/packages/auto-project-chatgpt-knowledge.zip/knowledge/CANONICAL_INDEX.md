# 倍特工作室 Canonical Knowledge Index

status: current
effective_date: 2026-10-08
last_verified: 2026-10-08

本目录是倍特工作室知识库的 Canonical 层。后续处理 SQL、数据分析、埋点、看板、排查、项目规则时，优先读取本文件，再读取对应 Canonical 文档。

换账号 / 新会话接手时，先用 [《自动项目》交接入口](../projects/auto-project/START_HERE.md) 定位当前状态与资料缺口，再按本索引读取稳定规则。交接状态和一次性分析记录不覆盖本层项目口径。

项目名、系统编号和入口的登记源为 [项目注册表](../catalog/project-registry.json)，可读视图见 [项目索引](../catalog/PROJECT_INDEX.md)。知识源与技能生成副本的边界见 [仓库维护规则](../docs/repository-maintenance.md)。

## 读取优先级
1. 当前用户明确指令
2. 本文件
3. knowledge/global/*
4. knowledge/projects/<项目>/*
5. 对应 tracking YAML
6. memory/projects/ 中最新专题规则
7. sql/ 中最新已验证 SQL
8. 历史 knowledge/、weekly_notes/、analysis 资料

## 全局 Canonical
- global/metric_definitions.md：统一指标字典
- global/sql_rules.md：SQL 编写/参数/输出规范
- global/lifecycle_maturity.md：D1-Dn、成熟、历史快照
- global/identity_channel.md：账号/角色/设备/渠道身份
- [global/ta_analysis_foundations.md](global/ta_analysis_foundations.md)：数数分析主体、埋点、模型选择与新增留存
- [global/ta_funnel_distribution.md](global/ta_funnel_distribution.md)：数数漏斗窗口、转化分母与分布区间
- [global/ta_data_menu.md](global/ta_data_menu.md)：数数数据菜单、埋点查证与登录枚举
- [global/ta_dashboard_migration.md](global/ta_dashboard_migration.md)：数数跨项目看板迁移、虚拟属性、用户标签与验收清理
- global/payment_policy.md：支付金额、首日/累计付费、代币与去重
- global/data_quality_playbook.md：异常排查手册
- global/field_pitfalls.md：字段/事件/类型易错清单
- global/analysis_method.md：统一分析方法

## 项目 Canonical
- projects/xiafangle/FACTS.md
  - [SLG 活跃付费与回访口径](projects/xiafangle/SLG_REVIEW.md)：项目 41 的上线前后对比、礼包映射、VIP 分层和回访观察窗。
- projects/wanyue/FACTS.md
- projects/bubu/FACTS.md
- projects/baodanfeshe/FACTS.md
- projects/jisuchongci/FACTS.md（极速冲刺：用户已确认 v39，埋点文档已整理）
- projects/luobo4/FACTS.md
- [projects/bietuiwodeta/FACTS.md](projects/bietuiwodeta/FACTS.md)：别推我的塔的现金与代金券口径、原生留存及首日付费分层

## 企微运营专题（2026-10-12）
- [projects/game-community/WECOM_DASHBOARD.md](projects/game-community/WECOM_DASHBOARD.md)：项目35社区账号人数主体、分游戏数据源、好友指标忽略、比例四位小数及局部维护约束；下方了与一步两步均已实施账号主体变更；各看板布局和日期设置保持其各自范围。

## 版本规则
- Canonical 文件只保存“当前有效且可复用”的事实/规则。
- 一次性版本结论、阶段性分析结论不得写入 Canonical。
- 旧规则保留但必须标记 historical / superseded。
- 新规则若替代旧规则，应在新文件写明 supersedes。
- 字段、金额单位、表后缀、关联键、分子分母等变化，必须优先更新 Canonical。

## 维护原则
任何长期有效的新口径，在用户确认后应同步到本层或对应项目专题文件；若影响跨项目，则同时更新本索引或 global 文档。
