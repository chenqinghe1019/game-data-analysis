---
name: auto-project-handoff
description: 盘点倍特工作室《自动项目》的当前进度、项目索引、技能、资料缺口和账号迁移交接包，适用于换GPT/Codex账号、新电脑接手、知识整理与GitHub交接保存，不替代具体SQL或小时报执行。
---

# 自动项目交接

工作区的本地Codex项目和ChatGPT项目可能都叫《自动项目》，先用可用项目/聊天工具核对范围，按来源分别记录。聊天标题不能用来推断游戏归属。

仓库入口 `projects/auto-project/START_HERE.md`。读取当前STATUS、项目索引、根工作规范和Canonical知识；工作区不可用时，先参考附带的[状态快照](references/STATUS.md)和[换号清单](references/ACCOUNT_HANDOFF.md)，并明确它们的核查日期。

盘点应区分：实际源码/文件与运行证据、历史聊天完成声明、模拟草稿、未完成与资料缺失。不能把找不到的旧源码重新实现后称为原版找回，也不能将无法取得的云端附件标为已备份。

只保存任务涉及的用户要求、最终决策、结果、来源和下一步，不导出模型推理、无关聊天或凭据。跨账号需要独立确认仓库与业务系统授权；资料包不等于执行权限。

采用项目自带 `scripts/collect-materials.py` 导出明确选择的成品和文件校验清单，`scripts/package-handoff.py` 生成技能与知识包。整理操作不启停任务、不触发推送、不覆盖生产库。按用户授权保存GitHub，推送后验证远端提交。

项目身份与职责对应以 `catalog/project-registry.json` 为登记源。修改已登记源文档后运行 `python scripts/repo-maintenance.py build` 和 `check`；参考副本和包不手改。本机安装是明确的 `--install` 选项，构建不发布插件或自动更新GPT知识。

交付应给入口、覆盖范围、校验结果和缺口；换号用[验收样例](references/ACCEPTANCE.md)核对业务规则，不能承诺账号历史、记忆、工具和模型行为完全无缝。
